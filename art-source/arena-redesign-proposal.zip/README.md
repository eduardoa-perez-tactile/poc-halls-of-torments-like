# Arena redesign visual proposal — 2026-11-23

Status: PROPOSED, not implemented or approved runtime art.

Generated with the built-in image_gen tool. The first original concept established the stone palette and landmark groups; a targeted edit corrected the room to the diamond-shaped 2:1 isometric projection. Both exact prompts and the reference input are retained here.

- proposed-layout.png: final visual proposal for review.
- reference-concept.png: first generated input used by the projection correction.
- concept-prompt.txt and projection-prompt.txt: exact creative instructions.

This is a level-design overview, not a flattened runtime background or a dimensionally validated tile kit. Production should use separate tall wall modules, compatible prop sprites, measured footprint/pivot metadata and authored placement data as described in docs/arena-redesign-proposal.md. Interior solid obstacles versus an open arena remain a user choice. Existing game art is preserved.
