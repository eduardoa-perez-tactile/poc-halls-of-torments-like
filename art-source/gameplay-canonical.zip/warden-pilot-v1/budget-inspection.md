# Independent front-facing Warden source inspection

2026-11-13. Read-only visual QA of `source-front/SE-raw-v2.png` and `source-front/SW-raw-v1.png`. Full sheets and memory-only enlarged crops of walk legs and the southwest downed pose were inspected. No image source, normalized frame, manifest, runtime file or branch was changed. This is static anatomy inspection, not timed playback or an in-engine check.

## Southeast walk

Frame 1 reads as the far/anatomical-left leg leading: its knee/shin descend on the screen-right side of the tabard into the extended forward boot. The near/anatomical-right thigh connects to the bent rear leg on screen-left.

Frame 3 is materially different from a mere boot-position swap: the near/right thigh appears to run diagonally forward behind the sword into the extended front knee/shin; the other leg folds behind. The boot projections still occupy roughly the same screen sides, which is not sufficient evidence of a repeated lead. **The repaired contact poses plausibly alternate anatomical leads.** The tabard and oblique sword hide the upper-leg crossover, however, so the hip-to-knee chains are less clear than ideal. Do not claim a rigorously verified gait from this static sheet alone.

Frames 2 and 4 change the other knee between trailing and raised-forward passage shapes, but the pelvis/root and tabard obscure support-leg continuity. Timed loop inspection remains necessary, especially the 2→3 exchange and 4→1 closure. This is improved contact-pose evidence, not a full motion pass.

## Southwest walk — unresolved alternating gait

Frames 1 and 3 appear to retain the same anatomical lead. In both, the near hip on screen-right connects through a rearward thigh/knee to the tucked screen-right boot. The other leg extends down-left into the leading boot. Frame 3 shows a different knee-cap overlap beneath the tabard, but I cannot trace a clear opposite hip→knee→ankle chain that establishes an exchanged leading leg.

**Blocking for claiming a completed alternating walk:** the southwest source should receive a targeted opposite-leg contact correction or remain explicitly flagged as an unresolved gait in the pilot. Screen-left/right boot locations alone are not the basis for this verdict; it is the visible upper-thigh and rear-knee connection.

## Sword hand

No clear hand swap was observed in either sheet. In the southeast view the weapon connects to the near anatomical-right shoulder→upper arm→forearm→grip chain. In the southwest view that right arm is farther from the camera and projects to screen-left in standing/walking poses; the sword remaining on screen-left is therefore consistent, not evidence of a swap. The southwest attack poses continue from that arm even when it reaches across the torso.

The southeast downed pose retains the sword in the near/right hand. In the southwest downed pose the visible near arm ends in an empty fist; the other forearm, partly under the helmet, reaches the sword grip. That is compatible with the anatomical-right weapon arm in the rotated side-lying body. Occlusion limits certainty, but no contradictory extra hand or obvious left-handed grip is visible.

## Other limits

Sword angle/shape and cloth edges vary across action poses, and the raw sheets contain colored fringe/speckle pixels. Final alpha cleanup, fixed-root extraction, weapon clipping, state transitions and gameplay-size readability belong to normalization and viewer inspection. This report does not approve the entire kit, a packed atlas, camera calibration, animation timing or runtime integration.
