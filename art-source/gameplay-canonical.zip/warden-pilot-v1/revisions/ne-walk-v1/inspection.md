# Northeast walk revision findings

## Selected result

`raw-v4.png` is selected. It is a1254×1254 RGBA image with2×2 cells of627×627, in row-major order1,2,3,4. Frame1 near/right sword-side leg is forward and frame3 near/right leg trails down-left while the far/left boot advances up-right behind it. Frame2 supports on right with left passing; frame4 supports on left with right passing. Primary plus independent static inspection agree these are now opposite leg contacts/supports, rather than the old repeated-right half-cycle.

`raw-v3.png` achieved the articulation from the solid3D diagram but introduced rear shoulder disks and gold cape piping. The final v4 costume-only edit removed those and preserved the leg poses. User motion review is still required; cloth partly occludes the upper leg chains and helmet shape is somewhat wider/squatter than the earlier source.

## What changed the result

The first two2×2 whole-strip attempts still copied the same near/right leading leg. A wire/line schematic, even made the primary edit target, did not overcome the painted seed pose.

`build-volume-guide.py` instead constructs an original code-native solid volume diagram with orthographic30degree elevation/45degree camera, equal-length2-link kneeIK, actual opposite hip/ankle target coordinates, occlusion-sorted thigh/shin cylinders and attached foot cuboids. Red identifies RIGHT and cyan LEFT only in the diagram. It is not final sprite artwork and none of those diagram pixels are sampled into exported bodies. Built-in ImageGen painted the full four Warden poses in one pass from that volume guide plus costume reference.

## Normalization handoff

See `selection.json`. Parent chose whole627square cells to362square, one common source root(181.8,332), and one shared source scale0.94 applied with base canonical scale0.285 for all4. This registers the helmet and keeps head/stride extents in the canonical cell without per-frame foot centering or alpha fitting. Foot-ground extent changes are part of the authored stride. Raw outputs remain unchanged.

## Evidence and scope

All4 raw attempts, exact prompts, code-native wire and volume guides, identity crop, source hashes and measured bounds remain in this owned folder. Source and canonical animation generation, palette/style transfer and costume cleanup used built-in ImageGen. This task changed no normalized kit files, runtime assets/code, build files, shared docs, branch or Git state.
