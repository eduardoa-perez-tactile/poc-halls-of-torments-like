# Independent northeast walk cross-review

Read-only inspection of sibling `../ne-walk-v1/raw-v3.png`, compared with its failedv2. Cropped/enlarged diagnostic views are saved only in this owned NW revision folder (`ne-cross-review-contacts.png`, `ne-cross-review-passages.png`); no NE source was edited.

**Qualified static pass for alternation.** Passage poses2/4 provide the clearest evidence: in2, the near anatomical RIGHT thigh/knee/shin descends into the planted support boot, while the far LEFT boot is lifted behind. In4, that near RIGHT thigh is raised and its foot lifted; the far LEFT shin and boot take support. These are opposite connected support configurations rather than the same leg repeated.

Contact1 exposes a prominent near RIGHT forward thigh/knee next to the sword hand. Contact3 removes that projecting thigh; a narrow/receding near hip/thigh and central trailing leg are consistent with the opposite contact. The long red cloth hides portions of both upper-leg connections, so the exact complete hip-to-knee chain in3 is not certifiable from visible pixels alone. The changed contact silhouette plus clear opposite passage configurations form a plausible complete alternating cycle, unlikev1/v2.

Identity differences in v3 include unwanted round rear shoulder clasps and extra gold cape edging; the NE agent is performing a targeted identity cleanup that should preserve the leg geometry. Brown boot soles/bands are more visible than in the earlier source, and cape fold shapes vary slightly. Right sword hand, closed rear helmet and blue/red palette remain consistent. Recheck cleaned v4 to ensure the alternating leg poses survive.

No timed playback, normalized pivot/loop closure, engine or physical-TV motion certification is implied by this static anatomical review.

## Cleaned v4 follow-up

Independently inspected sibling `raw-v4.png` after the identity-only cleanup. Rear shoulder clasps and added gold cape hem are gone. The four lower-body configurations remain materially the same as v3: passage2 still plants near RIGHT / lifts far LEFT, while passage4 lifts near RIGHT / plants far LEFT. Contacts1/3 retain their changed forward-thigh versus long trailing-leg silhouettes. The qualified static alternation pass therefore survives cleanup; the earlier repeated-same-leg failure is not present in the same form. Contact3 upper-leg continuity remains partly hidden by cloth, so no stronger 3D-rig/anatomy certification is claimed.
