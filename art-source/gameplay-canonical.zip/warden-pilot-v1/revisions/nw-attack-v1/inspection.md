# Northwest sword attack revision

Selected source: `raw-v2.png`, built-in ImageGen targeted repair after `raw-v1.png` exposed the sword but shrank the body and raised the blade too far above the head. Exact prompts and original tool-output paths/hashes are preserved in the sibling provenance files.

The selected image is1254×1254 RGBA with a2×2 grid,627×627 source cells. Poses are row-major: immediate contact, follow-through, retract, ready. The sword remains connected to the far anatomical right arm; the near anatomical left glove stays lowered and empty in all four poses. The first blade is clearly visible to the left/up-left of the helmet; the second is visibly steep up-right beyond the far shoulder. Recovery and ready progressively lower the right elbow/blade. This is substantially clearer than the earlier mostly occluded attack. There is no added anticipation pose, trail or other effect.

## Shared-scale and root inspection

The generator independently positioned bodies within its equal slots, creating a large raw horizontal root shift. Do not feed these cells into a common X root without correction. `suggested-normalization.json` records four explicit boot-landmark roots. These came from the fixed alpha>=96 boot band y512..600: horizontal centroid of boot pixels, plus the ground's maximum occupied y. Their raw roots are(364.12,587), (294.73,587), (348.67,580), (293.87,580).

All four poses use one shared physical scale: `.94` relative to the pilot's existing `.285` scale on362-equivalent source cells. This matches helmet/body dimensions to the approved idle more closely. The same scale and explicit landmark translations produce the fixed96×96 inspection frames, root(48,90). This is not independent alpha-box fitting or per-pose rescaling. Source pixels are only threshold-cleaned/resampled for the inspection exports; raw PNGs are unchanged.

`inspection-contact-sheet.png` shows those96px frames enlarged2× at a common scale. The first strike and follow-through have clear different blade silhouettes; planted feet and helmet stay broadly steady. Minor cape/plate/weapon shape changes remain. The far arm crosses behind the helmet in the contact pose, so part of its middle chain is naturally occluded. No frame-by-frame body redraw, mirroring, gameplay timing change, runtime or physical-TV verification was performed.

The inspection GIF is a slow presentation helper, not the180ms game action; the main pilot manifest must retain four45ms poses and continuous player movement. User approval and the main integrated art mockup remain pending.
