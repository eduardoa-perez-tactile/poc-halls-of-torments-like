# Warden pilot texture budget — 2026-11-13

Exploration only. Current source and existing logs were read; no build, emulator, gameplay run or runtime change was performed. Exact bytes, source hashes and candidate geometry are in `budget.json`.

## Current residency

The current source allocates the 3 MiB gameplay bank and 3 MiB equipment bank together with the menu/UI resources. Existing `.run/menu-ambient-final.log` confirms 22.065632 MiB of UI textures and 31.315632 MiB combined before QR. One live 360 × 360 RGBA QR adds 0.494385 MiB: **31.810017 MiB total**, leaving **0.189983 MiB** under 32 MiB. All values use raw RGBA8888 dimensions without mipmaps; PNG file sizes do not establish GPU cost.

| Resource | MiB |
|---|---:|
| Portrait source | 6.002571 |
| Shared menu crypt | 7.062500 |
| Font atlas (one observed page) | 4.000000 |
| Panel | 1.000000 |
| Button pair | 1.750000 |
| Home logo | 2.250000 |
| UI fill/rim | 0.000561 |
| Gameplay bank | 3.000000 |
| HUD atlas | 0.500000 |
| Outcome titles | 2.000000 |
| Skill atlas | 0.750000 |
| Equipment atlas | 3.000000 |
| **Current total before QR** | **31.315632** |
| QR if live | 0.494385 |
| **Conservative total with QR** | **31.810017** |

The new Warden kit must replace part of the existing gameplay bank. A separate additional 1 MiB Warden texture would exceed the current combined limit. This is a non-atomic source snapshot; later integration must repeat the actual residency check. An additional 1024² font page costs 4 MiB and is not included because the existing log reflects one page.

## Forty-eight frame candidates

The agreed kit has 12 cells per facing × 4 authored facings: idle1 + walk4 + attack4 + dodge1 + hit1 + downed1. Outer cell dimensions below include gutters. Every row is a valid equal-cell grid placement, but it is not a packed final artwork export.

| Outer cell | Occupied cell area | Example physical page | Page GPU cost | Unused page area |
|---|---:|---|---:|---:|
| 80 × 96 | 1.406250 MiB | 512 × 768 (6 × 8 cells) | 1.500000 MiB | 24,576 px |
| 64 × 80 | 0.937500 MiB | 512 × 512 (8 × 6 cells) | 1.000000 MiB | 16,384 px |
| 64 × 64 | 0.750000 MiB | 512 × 384 (8 × 6 cells) | 0.750000 MiB | 0 px |

Tight rectangular alternatives are possible: 480 × 768 for eighty-by-ninety-six cells (1.40625 MiB), and 512 × 480 for sixty-four-by-eighty cells (0.9375 MiB). NPOT pages are a candidate with linear filtering and no mipmaps, not an instruction to change runtime code. A 512 × 384 sixty-four-square page is already a bounded rectangular page. Square pages are not a project requirement.

**No whole-cast fit is proven.** Two hero kits at 64 × 80 occupy 1.875 MiB before physical-page waste. A 1 MiB environment allocation then leaves only 0.125 MiB of the existing 3 MiB bank for five enemy types, their states/directions, shadows, pickups and effects. Two 1 MiB hero pages plus 1 MiB environment leave none. Even two 64-square hero kits plus environment leave only 0.5 MiB for all enemies/FX. Do not use the earlier 6–7 MiB gameplay proposal: the equipment bank superseded that envelope.

## Pilot recommendation

Keep one high-resolution canonical canvas, consistent pixel scale and declared root per actor. Export the pilot with 80 × 96, 64 × 80 and 64 × 64 comparison sizes if practical; prefer 64 × 80 as the first constrained review candidate, while inspecting sword reach and downed/dodge extents. Do not independently fit/rescale each frame to force it into a cell. A cell that clips the sword or compresses the body is a failed candidate.

For a later whole-cast pack, trim transparent borders only, preserving the original canvas size, trim offset and pivot in metadata. This can retain animation alignment while recovering unused area; it must be demonstrated with the actual regions and environment before promising a full cast under 3 MiB. Trimming does not save GPU bytes when the same full physical page remains allocated. File-backed managed pages can avoid retained decoded Pixmaps, but do not reduce page GPU cost.

## Gameplay-size reference

At 1920 × 1080 the current renderer draws a 96 × 120-world-unit player region. Solo camera width is 1100 world units, giving a **209.45-pixel full draw cell**; each 960-wide co-op pane uses 650 world units, giving **177.23 pixels**. Existing artwork has about 142 opaque body pixels in its 160-pixel region, giving approximately **185.89 pixels visible body height solo / 157.29 split**. The old 185/155 figures are thus reasonable visible-body approximations, not full-cell heights. The new export must define visible body scale separately from padding, sword extents and root.

## Superseded pause assumption

The old `individual-review/02-warden-animation-plan.md` says combat/animation continue during phone upgrade choices. That statement is stale: current approved skill choices pause combat and simulation globally; only skill-choice countdowns advance. Animation driven by simulation freezes too. Manual pause, background and controller disconnect freeze simulation and choice clocks. No clock behavior is changed by this art pilot.

## Validation limits

The page geometry and existing runtime scale were calculated, source dimensions checked, and current allocations compared with saved startup logs. No new runtime measurement, visual acceptance, in-engine animation check, sustained performance check or physical-TV test was performed. The exact final atlas and frame extents remain primary-agent deliverables.
