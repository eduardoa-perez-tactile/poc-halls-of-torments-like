# Warden pilot review

Open `index.html` for the animation desk, all-pose board, solo arena and independent split-screen camera mockup. The resolution selector compares the canonical export with the uniformly reduced `budget64` variant, at the same nominal TV size. `kit-data.js` is a generated snapshot of the parent kit manifest and read-only source alpha bounds, so opening the review directly from disk needs no web server.

The arena reuses separate approved cutouts from `../../individual-review/`. Floor tiles are cropped from the approved three-variant board and diamond-clipped into a repeated ground. They remain illustrative tile samples, not production seamless exports. Shadows and the thin sword arc are review-only canvas primitives. The Ranger is a static approved appearance for scale. Warden alone uses the new animation kit.

Run `node capture-review.cjs --gif` to refresh four 1920×1080 deterministic screenshots, an optional budget-resolution desk screenshot and 12-second motion previews (six seconds solo, then six seconds split-screen, using one continuous scripted timeline). The sharp VP8 WebM is 960×540 at 10 preview samples per second; the lightweight fallback GIF is 480×270 at six samples per second with one shared 48-color palette. These presentation sample rates are unrelated to the target runtime frame rate. Arena strikes play once for 180 ms while the root keeps moving, then return to walking; the illustrative sword arc uses the same strike phase.

The script starts a loopback HTTP server, checks all facing/action selectors, resolution switching and direct-file opening, captures the declared timestamps, then stops its server and browser. Intermediate capture PNGs are removed.

The preview is not game footage, a gameplay test, a GPU-memory measurement, collision/damage validation or evidence of 60 FPS on a TV. The shared world and camera paths are scripted art presentation only. Nothing is integrated into the LibGDX runtime.
