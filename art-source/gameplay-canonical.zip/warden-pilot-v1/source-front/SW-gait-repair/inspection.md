# Southwest walk repair inspection

One built-in ImageGen whole-sheet edit was made from `../SW-raw-v1.png`, preserving the character/facing and targeting only the top walk row. Exact prompt, source/output hashes and extraction boxes are recorded in `provenance.json`. Raw output is retained unchanged.

## Result

The targeted repair is an improved static alternating-leg candidate. Frame 1 retains the far/anatomical-right leg leading and the near/left leg trailing. In frame 3, the tabard now swings screen-left and exposes the near/left upper thigh, which can be traced from its screen-right hip diagonally down-left through the forward knee into the leading boot. The far/right leg folds behind. This addresses the original sheet's repeated near-thigh rearward chain rather than merely moving boot silhouettes.

Frames 2 and 4 now show opposite support/passages more clearly: frame 2 has the near/left knee lifted and far/right supporting; frame 4 has the far/right knee lifted and near/left supporting. Sword remains attached to the far anatomical-right arm. The result is not a mirrored sprite.

## Selected coordinates

Returned dimensions are 1448 × 1086, the same as the source: four columns × three rows, 362 × 362 per cell. Use only row 0, y = 0..362, x = 0..362 / 362..724 / 724..1086 / 1086..1448. Preserve attack and held-state rows from the original source. The generator changed those rows slightly despite the preservation request.

## Limits

Full raw and enlarged memory-only leg crops were inspected; all twelve alpha cells are nonempty. This is a static anatomical improvement, not timed playback approval. Normalized root/scale, sword/cloth consistency, transitions and loop closure still need the primary viewer check. No source editing, atlas normalization, runtime integration, branch operation or additional generation was performed here.
