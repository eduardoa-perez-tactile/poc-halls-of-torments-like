# Warden pilot v1 — review before integration

Original Couch Crypt Warden artwork, generated with the built-in ImageGen tool from the approved orientation references. The Sprite Pipeline workflow supplied whole-sheet generation and common-scale normalization. All files remain in the ignored art exploration directory. No runtime asset, code, build file, shared documentation, branch or commit was changed.

Open `review/index.html` for the animation desk, all-pose board, solo arena and shared-world split-screen mockup. The canonical / compact selector draws both versions at the same nominal TV size. Scripted cameras, movement, sword arcs and state transitions are presentation only; this does not run LibGDX, combat or controller networking.

## Animation kit

Four separately generated facings: SE, SW, NE, NW. Each has idle1, walk4, attack4, dodge1, hit1 and downed1: **48 frames**. Asymmetric equipment was not mirrored to manufacture directions. Body frames have transparent backgrounds; review shadows are separate and reusable.

- `kit.json`: frame paths, preview timings, common pivots, four-direction/state structure, atlas rectangles and trimming offsets.
- `frames/`: canonical96×96 RGBA frames, common destination root(48,90).
- `frames-budget64/`: uniformly reduced64×64 RGBA comparison, root(32,60).
- `atlas-canonical.png`: actual512×640 RGBA page, **1.25 MiB** without mipmaps.
- `atlas-budget64.png`: actual512×320 RGBA page, **0.625 MiB** without mipmaps.
- `normalization.json`: exact source rows, cell boxes, source hashes, shared scale and explicit state-group root translations.
- `source-selection.json`: selected generation passes and row overrides; discarded attempts remain alongside their prompts/provenance.
- `motion-kit.gif`: compact walk/strike presentation. Its common65ms sampling is for side-by-side inspection, not gameplay timing.

The180ms attack sequence begins with contact and has no preparatory damage delay. Single-frame dodge/hit/downed durations in the viewer are review holds, not added game locks. Movement continues during scripted attacks/dodges. Approved skill-choice pauses, manual pause, background and participating-controller disconnect must freeze simulation animation in any future integration; the old standalone animation proposal's skill-choice clock statement is superseded.

## Known limitations requiring review

**Northeast walk is not production-ready:** it still repeats a leading leg. The explicit guide-based repair also failed, so the cleaner source is retained rather than concealing the issue. SE opposing leg chains are plausible but partly occluded by the tabard/sword; SW's targeted gait repair makes the opposite leg contacts clearer. All still need human motion review.

The NW attack was repaired to preserve right-handed equipment; the far arm/sword is naturally hidden, making its motion subtle. Cloth, plate and blade shapes vary slightly across generated frames. Exact common-camera calibration, four-direction turns, attack/dodge transitions and final ground pivots are unproven. State groups use declared source ground translations, not independently fitted per-frame alpha boxes; lying poses use a resting-body ground center.

Floor/prop appearance sources are approved, but the mockup's repeated diamond-clipped floor samples do not establish production seamless tile joins. Static Ranger art is scale context, not a completed Ranger animation kit.

This pilot alone does **not** prove that the full cast fits the existing3MiB gameplay allowance. Current source/saved-log audit reports31.810017MiB with QR and existing gameplay resources; new assets must replace textures or use separately approved savings. See `budget.md`. No in-engine memory, collision, frame-time or physical-TV performance claim is made.

## Reproduction and evidence

Run `python3 build-kit.py` from any working directory. It performs deterministic threshold/speckle cleanup, fixed-cell extraction, shared scale, declared group roots, transparent trimming and no-rotation packing. Raw tool outputs remain unchanged. The atlas verifies non-overlapping rectangles and exact unpacked RGBA reconstruction for all48 frames in both variants. Normalized content has a transparent outer margin.

Then run `node review/capture-review.cjs --gif` to refresh the bounded visual review captures. Its server/browser and intermediate frame captures are stopped/removed after use. Exact ImageGen prompts and raw tool-source provenance live in `source-front/` and `source-north/`; these source images and large review boards are not shipping assets.
