# Warden pilot v2 — northeast walk / northwest strike revision

Prepared for user review inside the art exploration directory. No runtime integration, code/build/shared-documentation changes or Git actions.

Open `review/index.html` for the before/after comparison and updated arena mockup. The original v1 remains intact. The review independently loads v1 and v2 images at matched display sizes; it does not relabel the old preview.

## What changed

- **NE walk, four poses:** a solid-volume orthographic 3D pose guide established opposing contact and support legs where earlier line guides failed. The selected `raw-v4.png` keeps the changed leg poses while removing unwanted rear clasps/gold cape edging. Poses1/3 exchange contacts;2/4 exchange support. Contact3's upper leg is partly covered by cloth, so inspect the actual motion, not a prompt label alone.
- **NW sword attack, four poses:** the sword now reaches visibly left/up-left outside the body, swings up-right in follow-through, then retracts/returns ready. The far anatomical right hand retains the sword; the near left hand stays empty. The action still begins in contact, using the original180ms total timing.
- **Forty other frames are byte-identical to v1** in both canonical and compact exports.

All final art was generated with the built-in ImageGen tool. Exact prompt sets, raw passes, original tool paths/hashes and independent inspection notes are retained in the sibling v1 revision folders:

- `../warden-pilot-v1/revisions/ne-walk-v1/`: selected `raw-v4.png`; `prompt-v1.txt` through `prompt-v4.txt`; volume guide geometry/code; provenance and inspection.
- `../warden-pilot-v1/revisions/nw-attack-v1/`: selected `raw-v2.png`; prompt/provenance; boot-landmark diagnostics, suggested normalization and independent NE cross-review.

## Normalization and texture allocation

Dedicated4-pose strips use2×2 square cells; selected sources are1254×1254 RGBA with627px cells. Grid coordinates are uniformly mapped into the earlier362px virtual cell space. NE uses one fixed root and one0.909 scale multiplier for all4poses, calibrated against the earlier idle helmet/ground-root position. No walking pose is independently alpha-fitted, recentered or foot-locked.

NW uses one0.94 scale multiplier for all4poses. Four explicitly recorded boot-landmark translations correct the generator's slot-placement drift, without independent resizing or alpha-box fitting. See `source-selection.json` and `normalization.json` for every transform.

The complete48-frame kit still uses96×96 canonical frames (root48,90), plus a uniform64×64 comparison (root32,60). Actual trimmed RGBA8888 pages without mipmaps:

| Version | Atlas | GPU allocation |
| --- | --- | --- |
| Canonical |512×640|1.25MiB|
| Compact64|512×320|0.625MiB|

These match the previous pilot allocations. Full-cast packing within the existing3MiB gameplay allowance remains unproven; this revision adds no runtime textures.

## Verification and limits

`verification.json` records exactly8changed/40unchanged frames per variant, expected state counts/timing, RGBA dimensions, transparent outer margins and exact atlas-to-frame reconstruction. The builder also verifies non-overlapping packed rectangles. The viewer records its focused control/capture/media checks separately.

The updated preview is scripted art presentation, not LibGDX gameplay or a physical-TV performance test. Its30Hz presentation sampling is chosen to show the45ms sword poses, not to measure runtime frame rate. Camera calibration, turn/transition polish and minor generated helmet/cloth/plate variations still require final review. Human approval of this revised kit remains pending.

Rebuild with `python3 build-kit.py`, then `node review/capture-review.cjs --gif` (the capture option refreshes the lightweight WebM). Rebuilding needs the preserved sibling v1 sources; exported frames/atlases are self-contained image outputs. Temporary browser/server/capture frames are removed after review capture.
