# Ghoul directional kit

`kit.json` contains twenty 64×64 RGBA frames: SE/SW/NE/NW, each idle1 + walk4. The fixed anchor is (32,60); walking uses four 140 ms poses (560 ms loop). `contact-sheet.png`, individual `*-walk.gif` and `four-directions.gif` provide bounded previews.

All four directions were authored independently with built-in ImageGen. The approved warm gaunt flesh, hunched back, sparse hair, long forearms/hooked claw groups, bare feet and plum rags remain distinct from other enemies. There are no armor additions, weapon/attack gestures or new contact-damage windups. No horizontal image mirroring is used.

## Selection and gait review

- SE uses `se-raw-v1.png`, except WALK3/source slot3 comes from `se-raw-v3-extracted.png`. The original contact's hip ownership was obscured by the near claw. Reconstruction exposes the near right thigh/knee/ankle and shifts that claw aside. A further built-in background extraction pass corrected an opaque gradient introduced by the reconstruction.
- SW uses `sw-raw-v2.png`. The first attempt incorrectly retained SE facing and is preserved as a rejected pass. Passing/support legs read as exchanged in 2/4; contact 1/3 remains partly obscured by rags and claw and therefore receives a qualified static pass.
- NE keeps the original idle but replaces all walking frames with `ne-walk-raw-v2.png`, generated as a dedicated 2×2 strip from clear solid-volume hip/leg scaffolds and an upper-body-only identity reference. This prevents standing reference legs from overriding the four different chains. New 2/4 have visibly opposite support/lifted legs and 1/3 contacts read as opposite leads. The original NE walking strip failed this check and is retained.
- NW uses `nw-raw-v1.png`; 2/4 support exchange is clear, the rear head faces away and no eyes/mouth peek is visible.

The primary agent reviewed the updated canonical sheet and accepted this as a packing candidate. `gait-qa.json` retains the qualified checks. NE walking posture is more extended than idle and its head rises a few native pixels; actual idle/walk/turn comfort still needs the runtime check. No mathematically calibrated shared rig or perfect bone-length consistency is claimed.

## Normalization and memory envelope

`normalize_kit.py` reproduces the exports from retained raw sources. A single common actor scale is used, with one explicitly measured calibration applied uniformly to the entire replacement NE strip: the approved idle upper-back/shoulder span at logical512 y100..160 is 193 px, while the replacement WALK1 span is 172 px, giving **193/172 = 1.12209**. All four NE poses retain their relative geometry. This is not per-pose alpha-box fitting.

Every source slot maps proportionally to logical512 coordinates; the new NE 2×2 strip's actual 627-square slots share one 512/627 transform. The fixed source root is (256,496). Rigid upper-skull landmarks provide explicitly recorded integer translations of the complete pose for generated layout drift; no separate body-part warp or per-pose scale change occurs. Global source alpha below 96 and output alpha below 16 are cleared, removing unwanted reference-style halos/noise.

The final maximum trimmed rectangle, including a two-pixel gutter on each side, is **44×58**, below the advisory 56×64 envelope. Page packing and GPU residency are handled by the primary integration, not this asset task. Final metadata includes all source boxes, calibration factors, hashes and offsets in `normalization-report.json`.

All twenty PNGs and GIF frame counts/timing were checked, and canonical contact frames inspected. Continuous in-engine playback, physical-TV readability, atlas memory, draw calls and 60 FPS were not verified by this task. The existing cached Pillow/tooling was used; nothing was installed or downloaded. `provenance.json` indexes all eight generation passes, exact prompt files and input/output hashes, including failures.
