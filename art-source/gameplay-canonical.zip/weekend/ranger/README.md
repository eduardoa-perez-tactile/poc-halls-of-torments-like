# Ranger — complete44-frame directional candidate

Four separately authored facings: SE/SW/NE/NW. Eleven painted poses each: idle1, walk4, attack3(fire/recoil/ready), dodge1, hit1, downed1. No reload and no mirrored actor sprites. Canonical frames are96 × 96, anchor(48,90), at the Warden review world scale. `kit.json` follows the Warden directions/state/path/duration schema; the primary owns final joint packing and runtime integration.

## Sources and generation

Approved front identity comes only from the left half of `orientation-review/ranger/raw-v4.png`. Rear identity comes from accepted `ranger-rear-repair/rear-rebuilt-v1.png`, never the superseded broken rear. Deep teal hood/cloak, covered warm-brown leather torso, plain brown trousers/cuffed boots, compact crossbow and one bolt case are retained. Right hand triggers, left supports; rear body naturally hides much of bow/far arm rather than exposing a twisted front chest.

Built-in ImageGen produced four4×3 master sheets, one per facing. Middle-row fourth ready duplicate is excluded. Walking was not accepted from those masters: dedicated solid-volume2×2 walk targets and torso-only identity references gave more explicit opposing leg contacts/support. SE/SW/NW select walk-v2; NE required one targeted v3 correction after v2 repeated the near-right lead. All raw alternatives, exact prompts, tool paths and SHA256 hashes remain here. Nine whole-sheet generation calls total, no individual-frame painting.

`build-guides.py` reproduces both4×3 and2×2 code-native volume diagrams and identity crops. Its3Dhip/knee/ankle geometry is a pose constraint, not final pixel art or a rig substituted for painted assets.

## Normalization

`build-kit.py` emits all44RGBA frames plus contact/GIF previews. Masters use a shared0.267scale; all dedicated walks use shared0.15scale. Every canonical canvas remains96²/root(48,90). Exact source cells, per-strip roots, held-state root choices, and any translations are in `normalization.json`.

Walking columns showed rigid hood-placement drift: SE needed±19.25rawpx x shifts, SW about±11rawpx, NE±3.75rawpx, NW none. These are explicit rigid teal-hood landmark translations, not whole-body alpha-box recentering. Before-correction walking frames remain in `uncorrected/`. No walking frame is independently resized, foot-locked or body-fitted. Genuine vertical source variation remains. Shared-scale hood widths differ roughly3–7%from their master idle counterparts; some cloth/hood/weapon shape breathing remains visible. Tiny boot buckles in the SEwalk differ from the master and were accepted as minor variation by primary review.

Source alpha below96 and isolated tiny high-alpha components are removed before sampling; exported alpha below16 is cleared. Cleanup counts are recorded per frame. No source anatomy is repainted. Complete source silhouettes project inside every96²canvas; no frame is clipped to fit an atlas cap.

## Actual resource area

Summed trimmed outer rectangles, including2px gutters each side, occupy **194,354pixels /0.741402MiB RGBA8888**. Maximum individual outer width87px, maximum height93px. These actual extents are in `kit.json.trimmedRegions`; the soft Ranger caps were not enforced by distorting figures. The main must perform the real combined atlas pack. This is area evidence, not a claim that a separately allocated page costs0.741402MiB.

## Review

- `previews/kit-contact-sheet.png`: complete kit at2×nearest-neighbor diagnostic magnification; this is pixel inspection, not a pixel-art style change. Runtime uses linear filtering.
- `previews/SE-walk.gif`, `SW-walk.gif`, `NE-walk.gif`, `NW-walk.gif`: four130ms walking poses on a shared shadow.
- Matching `*-attack.gif`: fire70ms/recoil90ms/ready140ms. The shot itself is immediate at the first pose; no reload/delay/movement lock.
- `verification.json`:44expected frames, exact state counts, RGBA96², no projected source clipping, decoded GIF frame counts/timings.

Primary static review accepted SEwalk-v2 opposing legchains; SW/NWwalk-v2 received a qualified static pass with cloak-occlusion caveats. NEwalk-v3 improves the near-right trailing shin and opposite support and still awaits primary confirmation at this writing. Timed-loop comfort, native solo/split scale, directional transitions, collision/event alignment and physical-TV60FPS remain primary/user checks. The GIFs are generated/decoded; this subagent has not claimed an in-engine playtest.

## Clocks

All actor animation follows simulation time. Both skill and loot ceremonies pause combat/animation globally; only the active shared choice clock advances. Skills freeze hidden loot clocks. Manual pause, background and disconnect freeze simulation and choice timers.

No runtime files, approved menu/icon paintings, branches, commits or packages were changed. No installations/downloads/upgrades were performed.
