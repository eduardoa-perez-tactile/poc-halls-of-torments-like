# Emitter alignment audit

The new painted actors make the existing projectile and slash lifts visibly low. This audit proposes **fixed canonical landmarks** for primary review; it changes no source, actor art, collision, damage, timing or trajectory. Sovereign remains pending.

`emitter-diagnostic.png` marks the root red, the existing renderer lift cyan and the sampled muzzle/palm/grip yellow. The diagnostic uses canonical pixels rather than atlas crops. `emitter-anchors.json` includes source/kit SHA256 hashes and approximate landmarks (±2 canonical pixels). All12 Ranger attack images were inspected: first fire70ms, recoil90ms and ready140ms. Only the first fire pose emits; the later two are not additional shots. Cultist uses its single release image per facing.

## Coordinate conversion

`GameplayAtlas.Actor.pixelScale = worldHeight / canvasHeight`. The current packer assigns120/96=1.25 to Ranger/Warden and84/64=1.3125 to Cultist. `drawFrame` retains the canonical offset and pivot after trimming. For a point(x,y) on a top-left-origin source canvas:

```
dx = (x - pivotX) * pixelScale * enemyScale
dy = (pivotY - y) * pixelScale * enemyScale
```

These are projected rendering units relative to the actor ground root, not calibrated anatomical 3D heights. The painted pose includes projected depth. No alpha-bound recentering, per-pose scaling or imaginary joint fitting was used. At nominal1920×1080 the camera multiplies these offsets by1920/1100≈1.745solo or960/650≈1.477split; this is a calculation, not a TV measurement.

## Ranger crossbow

Canvas96², pivot(48,90), pixelScale1.25. Samples are the outer muzzle in each first-fire pose.

| Facing | Muzzle source px | Projected offset(dx,dy) | Lift above current+24 |
|---|---:|---:|---:|
| SE | (71,39) | (+28.75,+63.75) | +39.75 |
| SW | (19,35) | (−36.25,+68.75) | +44.75 |
| NE | (75,25) | (+33.75,+81.25) | +57.25 |
| NW | (23,25) | (−31.25,+81.25) | +57.25 |

`drawBolts` currently draws the arrow head at ground root+(0,24), with its21-unit shaft trailing. Raising a common lift to60–70 is a small improvement, but still leaves the rear muzzles high and all four horizontal offsets unresolved. Prefer the table’s fixed per-facing offsets, selected from the shot’s captured attack direction. Snapshot the visual offset at spawn and keep it constant in flight; following a living owner’s current facing/position would make arrows jump after turning or moving. Keep physical bolt coordinates, velocity, hit tests, TTL and damage unchanged.

## Cultist free palm

Canvas64², pivot(32,60), pixelScale1.3125. Samples use the free casting palm, not the staff. SW’s lowered palm is partly occluded at chest level; its landmark is less clear than the other three. The current projectile is drawn at(0,+18).

| Facing | Palm source px | Normal projected offset | Elite projected offset(×1.18) |
|---|---:|---:|---:|
| SE | (49,22) | (+22.31,+49.88) | (+26.33,+58.85) |
| SW | (28,33) | (−5.25,+35.44) | (−6.20,+41.82) |
| NE | (47,14) | (+19.69,+60.38) | (+23.23,+71.24) |
| NW | (15,25) | (−22.31,+45.94) | (−26.33,+54.21) |

`enemyScale` is1 for Cultist and×1.18 for elites; apply the same multiplier to both offsets. Current `Shot` now snapshots `casterKind`/`casterElite`, which preserves identity through caster death and pool reuse. A fixed source-facing/visual-offset snapshot would also preserve the chosen release palm. For an aimed shot its velocity selects the same facing; future boss fan directions must not automatically imply multiple differently posed palms.

One global `drawShots` lift cannot align these four poses and an unreviewed Sovereign. Keep the existing .7s windup, immediate live-target release and projectile mechanics. Sovereign’s renderer multiplier is2.2(then elite×1.18 if applicable); its approved release source and emitter must be measured separately.

## Warden sword effect

The first45ms strike poses have projected grip heights SE43.75, SW45.00, NE75.00, NW86.25. Approximate blade-tip heights are23.75,20.00,100.00,93.75 respectively. Rear poses deliberately hold the sword higher; the grip is not a universal slash-plane height.

The current slash applies+22 to a **full physical-range ground-plane arc**, not a short attached sword smear. Base reach160 projects the central forward point by±56.57y. Consequently SE/SW central arc points sit34.57 units **below** the ground root; NE/NW sit78.57 above. This is a concrete front-facing ground-slash risk. Simply assigning the blade tip’s projected y to the arc lift would count the ground projection incorrectly.

For a minimal visual-only prototype, retain cone, reach, effect lifetime, damage timing and sweep, and try a fixed per-facing lift around80 forSE/SW and40 forNE/NW. That puts the central arc near the first-pose blade-tip heights without per-frame fitting. It cannot make the broad160-range arc coincide with the shorter painted sword: its horizontal radius remains larger, and later poses vary. Primary should inspect the four facing transitions before deciding whether this remains a range effect or becomes a shorter separate visual smear. No mechanics change is requested by this audit.

## Checks and limits

Inspected exported canonical poses, loader trim/pivot math, actor scales, projectile creation/drawing and slash projection. No runtime launch, engine screenshot, physical-TV performance measurement or gameplay test was performed. No actor assets, source code, Git state, packages or dependencies were changed.
