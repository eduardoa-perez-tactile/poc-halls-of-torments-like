# Wraith directional kit

Twenty canonical RGBA frames: SE, SW, NE and NW, each with one idle frame and four drift frames. `kit.json` exposes `directions.{facing}.idle` and `.walk` paths, frame size 64×64, ground/hover anchor (32,60), and 180 ms per drift frame. The four-frame loop is 720 ms. Idle can be held.

The four directions were authored in separate built-in ImageGen calls, never horizontally mirrored. The first NW attempt retained the NE yaw and was rejected. `nw-raw-v2.png` is the corrected rear-up-left source: near sleeve on the left, back of hood visible, tails trailing to the right, no ivory face peek.

## Export and packing

`normalize_kit.py` reproduces the canonical PNGs, contact sheet, GIFs and metadata using the existing Pillow installation. No packages, downloads or upgrades were added.

- Actual source sheets are 1536×1024, arranged 3×2 in 512-square slots. Slots 0–4 are idle/drift1/drift2/drift3/drift4; slot 5 is an excluded idle duplicate.
- One common scale, **54/470**, applies to all twenty poses across all four directions. The fixed source-coordinate root is (256,496), mapping to native (32,60). There is no per-frame alpha-box fitting, resizing or body warping.
- The generator did not keep slot registration exact. Explicit integer whole-pose translations register the ivory-mask landmark (front) or rigid upper-hood landmark (rear) to that direction's idle. These corrections range up to +7 native pixels horizontally and +3 vertically. Every correction, source slot, hash and residual is recorded in `normalization-report.json`; raw sources remain intact.
- Global source alpha below 96 is cleared before the common transform, removing the unwanted translucent reference-style halo. Output alpha below 16 is cleared afterward. Other source colors and opacity remain unchanged.
- The largest actual trimmed rectangle **including two pixels of gutter on each side is 36×58**, below the requested 48×64 envelope. Packing/page residency is the primary agent's responsibility; this kit creates no runtime texture.

## Inspection and limitations

All twenty canonical poses were inspected on `contact-sheet.png`. Front views retain the ivory mask, purple hood, two empty short sleeves and two broad cloth tails. Rear views expose no face. Eye detail is small at 64 native pixels and needs the intended TV-scale review.

After the documented registration, maximum pairwise rigid-head residual is below 0.68 native pixels in every direction. Last→first head displacement is below 0.51 pixels; lower-tail centroid displacement at that seam is below 0.84 pixels. The output no longer makes the whole head/body walk monotonically sideways. Some SE/NW tail folds flex more than the requested six source pixels, so tail amplitude still varies slightly by direction.

`loop-qa.json` records the numeric measurements, source caveats and GIF decode/timing checks. The static image inspection tool exposes still frames; continuous playback comfort was not visually watched through that tool. There was no in-engine, physical-TV, performance or exact shared-3D-camera validation in this asset task.

Previews: `four-directions.gif` and individual `se-drift.gif`, `sw-drift.gif`, `ne-drift.gif`, `nw-drift.gif`. `provenance.json` indexes all five generation passes, exact prompt files, default raw locations and source hashes, including the rejected NW pass.

Only this ignored Wraith exploration folder was modified for this task. No runtime source/assets/tests or Git state were changed.
