# Brute —20-frame directional production candidate

Canonical64 × 64RGBA, root(32,60), four separately authored SE/SW/NE/NW facings. Each has one held idle plus four alternating heavy-shuffle walking poses. `kit.json` follows the shared directional/state/path/duration schema and exposes exact trimmed outer rectangles for the primary packer.

The approved massive bald hunched silhouette, warm ochre/tan skin, huge low fists, dark collar, rust loincloth and broad bare feet are preserved. No weapons/armor/new attack or contact-safe windup was introduced. Elite Brutes reuse this art and existing runtime cues/scale; hit/death remain existing feedback layers.

## Generation and rejected passes

Built-in ImageGen, six whole-sheet calls total: four2×3 facing sheets, one SEalpha correction and one NWfacing correction. The solid-volume3Dpose guides explicitly encode opposing hip/knee/ankle contacts/support. Torso-only identity references avoid copying approved standing legs into every walk phase. `build-guides.py` reproduces the guides/crops; every raw file, exact prompt, tool path and SHA256 is retained.

- SE-v1 correctly painted poses but failed true transparency (alpha165..251, bakedchecker). SE-alpha-v2 is the selected built-in background-extraction result, with properalpha0..254. No manualmatte/color-key repaint was used.
- SW-v1 and NE-v1 are selected. Allsourcefigures have truealpha; low-alpha colored haze/noise is cleaned uniformly offline.
- NW-v1 incorrectly remainedNE/up-right and is rejected. NW-facing-v2 uses strictNWvolume geometry plus a headlessback-material reference; head/collar/back/hips/feet now cohere up-left. It is separately generated, not a mirroredNEsprite.
- Sixth spare idle cell is excluded in every sheet, leaving20actual painted frames.

Primary static review accepted allfour facings as production candidates. Contact1/3and support2/4 exchange is readable; some farhip/knee connections remain partly hidden by muscle mass in rear views. This qualified static acceptance is not an in-engine or physical-TV motion pass.

## Fixed-canvas normalization

`build-kit.py` uses one shared source scale0.12 and source root(256,484) for the whole actor, mapping to64²/root(32,60). Every source is a1024 × 1536sheet with512²cells. No individual pose is alpha-fitted, independently resized, recentered by body bounds or foot-locked.

NEcolumns contain32raw pixels of rigid bald-head placement drift. A fixed14px top-of-scalp diagnostic measures that drift; explicit rigid x translations are[0.5,32.5,-0.5,31.5,0]raw pixels for walk1..4/idle. These affect whole figures, not joint anatomy. Other facings receive no translation. Vertical source bob remains. Alluncorrected frames are retained separately; allsourceboxes/roots/transforms/cleanup counts are in `normalization.json`.

Uniform source alpha below96 is cleared before sampling, then isolated tiny high-alpha components are removed. This removes the NEupper-body smoky halo: atalpha16itsboundsreachedthecelltop, whilealpha96bounds followthebodyanddiffer by aboutonepixelalongnormaledges. Exportalpha below16 is cleared. No silhouette is creatively repainted or eroded to meet a memory cap. The canonical contact sheet shows clean bodies without smoky scenery.

## Actual dimensions and verification

Twenty nonemptyRGBA64²frames, exact idle1/walk4counts per facing, and projected source silhouettes fully inside each canvas. Actual trimmed outer rectangles with2pxgutters sum **60,814pixels /0.231987MiB RGBA8888**. Maximum outer dimensions are **55 × 60**, below the tentative64 × 68limit. This occupied-area sum is not the GPU cost of a final physical page; primary must validate the full combined pack.

`previews/kit-contact-sheet.png` shows all20frames at2.5×nearest-neighbor diagnostic magnification. `previews/{SE,SW,NE,NW}-walk.gif` uses four200msposes, slow heavy motion without anattackwindup. EachGIF decodes as4frames with the expected timings. Runtime uses linear filtering; nearest preview enlargement is for inspecting source pixels, not a change to pixel-art direction.

`verification.json` records counts,RGBA dimensions, no-clipping assertions,trim area and decodedGIFtimings. Timed-loop comfort, native solo/split scale/ground anchors, directional transitions and sustained physical-TV60FPS remain runtime/user checks. Actor clocks must freeze with simulation during skill/loot ceremonies and manual/background/disconnect pauses.

No runtimecode/assets, otheractorfolder, Gitstate or dependencies were changed; no installs/downloads/upgrades/builds/playthroughs were performed.
