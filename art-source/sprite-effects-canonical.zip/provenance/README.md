# Approved original sprite effects

Created with the built-in image_gen tool on 2026-11-24, using the user-provided screenshot as visual inspiration. These are original generated raster sheets, not downloaded or baked Godot shader assets. Exact prompts are retained in review-input.json. The user approved the composited Warden/Ranger review before authorizing integration.

Ground sheets use measured rim centers and per-frame Y correction to the arena 2:1 plane. Original masters remain included. The sword source uses one shared 0.45 Y correction around its fixed anchor. No runtime perspective fitting, procedural rings or effect-line generation is needed. Pulse/impact rim fits have organic/low-confidence edges; faint particle-only frames inherit the nearest stable correction. Existing source clipping is not reconstructed.
