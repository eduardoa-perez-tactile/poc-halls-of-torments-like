#!/usr/bin/env python3
"""Normalize review-only original ground sprites by measured ground-rim anchors.

No painting, alpha cleanup, bounding-box fitting or per-frame size normalization.
The eight source cells are independently translated and vertically scaled from
measured ground ellipses. Complete source canvases fit within padded outputs.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parent


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    measurements = json.loads((ROOT / "ground-measurements.json").read_text())
    source_w, source_h = measurements["sourceCell"]
    cell_w, cell_h = measurements["outputCell"]
    pivot_x, pivot_y = measurements["outputPivot"]
    output = ROOT / "normalized"
    output.mkdir(exist_ok=True)
    manifest = {
        "version": 1,
        "method": "Measured ground-rim translation and per-frame measured ellipse vertical scaling only; originals preserved.",
        "cell": [cell_w, cell_h],
        "pivot": [pivot_x, pivot_y],
        "logicalPivot": measurements["logicalPivot"],
        "columns": 4,
        "rows": 2,
        "animations": [],
    }
    for effect_id, sheet in measurements["sheets"].items():
        source_path = ROOT / "sources" / f"{effect_id}-raw.png"
        original_sha = sha256(source_path)
        source = Image.open(source_path).convert("RGBA")
        if source.size != (source_w * 4, source_h * 2):
            raise ValueError(f"Unexpected source grid: {source_path}")
        normalized = Image.new("RGBA", (cell_w * 4, cell_h * 2))
        frame_metadata = []
        for i, frame in enumerate(sheet["frames"]):
            center_x, center_y = frame["center"]
            axes = frame["semiaxes"]
            if axes:
                scale_y = axes[0] / (2 * axes[1])
            else:
                known = [(abs(j - i), j, other["semiaxes"]) for j, other in enumerate(sheet["frames"]) if other["semiaxes"]]
                nearest_axes = min(known)[2] if known else None
                scale_y = nearest_axes[0] / (2 * nearest_axes[1]) if nearest_axes else sheet["fallbackVerticalScale"]
            # Full original canvas must remain within the padded output canvas.
            bounds = [
                pivot_x - center_x,
                pivot_y - center_y * scale_y,
                pivot_x + source_w - center_x,
                pivot_y + (source_h - center_y) * scale_y,
            ]
            if not (bounds[0] >= 0 and bounds[1] >= 0 and bounds[2] <= cell_w and bounds[3] <= cell_h):
                raise ValueError(f"Output padding would clip {effect_id} frame {i + 1}: {bounds}")
            x, y = i % 4 * source_w, i // 4 * source_h
            original = source.crop((x, y, x + source_w, y + source_h))
            # Pillow RGBA geometric transforms premultiply internally for the
            # resample. This changes no alpha except interpolation itself.
            transformed = original.transform(
                (cell_w, cell_h),
                Image.Transform.AFFINE,
                (1, 0, center_x - pivot_x, 0, 1 / scale_y, center_y - pivot_y / scale_y),
                Image.Resampling.BICUBIC,
                fillcolor=(0, 0, 0, 0),
            )
            normalized.paste(transformed, (i % 4 * cell_w, i // 4 * cell_h))
            axes = frame["semiaxes"]
            source_ratio = axes[0] / axes[1] if axes else None
            frame_metadata.append({
                "frame": i + 1,
                "measuredSourceGroundCenter": frame["center"],
                "sourceGroundSemiaxes": axes,
                "sourceGroundRatio": source_ratio,
                "normalizedGroundRatio": source_ratio / scale_y if source_ratio else None,
                "confidence": frame["confidence"],
                "verticalScale": scale_y,
                "transformedFullCanvasBounds": bounds,
            })
        target = output / f"{effect_id}.png"
        normalized.save(target)
        if sha256(source_path) != original_sha:
            raise RuntimeError(f"Original source unexpectedly changed: {source_path}")
        manifest["animations"].append({
            "id": effect_id,
            "originalRaw": str(source_path),
            "originalSha256": original_sha,
            "raw": str(target),
            "normalizedSha256": sha256(target),
            "columns": 4,
            "rows": 2,
            "cell": [cell_w, cell_h],
            "pivot": [pivot_x, pivot_y],
            "groundRadius": sheet["referenceGroundRadius"],
            "verticalScale": "measured per frame; see frames",
            "normalizationSummary": sheet["summary"],
            "frames": frame_metadata,
        })
        ratios = [m["normalizedGroundRatio"] for m in frame_metadata if m["normalizedGroundRatio"] is not None]
        print(f"{effect_id}: {target.name}; {cell_w}x{cell_h}/cell; pivot {pivot_x},{pivot_y}; corrected rim ratio {min(ratios):.3f}..{max(ratios):.3f}")
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()
